<?php
$option=$_GET['option'];

if($option=="area")
{
    
}
?>
