<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>


<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquery.min.js"></script> 
</head>
<body>
	<div class="header">
		<div class="header_top">
			<div class="wrap">
			 <div class="logo">
						<a href="index.php"><img src="images/47.png" alt="" /></a>
					</div>
			    <div class="call">
			    <p><img src="images/45.png" alt="" />Call US: 111-234-56789</p>
			    </div>
			  			 
			<div class="clear"></div>
  		</div>
  	  </div>
	<div class="header_bottom">
		<div class="wrap">
	     	<div class="menu">
	     		<ul>
			    	<li class="active"><a href="index.php">Home</a></li>
			    	<li><a href="login.php">Login</a></li>
			    	<li><a href="Customer_Add.php">Register</a></li>	
<li><a href="services.php">Services</a></li>					
			    	<li><a href="about.php">About Us</a></li>
			    	
			    	
			    	<div class="clear"></div>
     			</ul>
	     	</div>
	     	<div class="social-icons">
	     		<ul>
	     			<!----------------login------>
	     		</ul>
	     	</div>
	     	<div class="clear"></div>
	      </div>	     
	  </div>	


	
	     	<div class="clear"></div>
	      </div>	     
	  </div>	
	   <div class="strip"> </div>
    </div>  
 <div class="main">
    <div class="content">
    	 <div class="wrap">
    	 	<div class="services">
    	 		 <h2>Our Services</h2>
				<div class="section group">
				  <div class="col_1_of_4 span_1_of_4">
				  <img src="images/corporate-b.jpg" alt="" />
					<h3><span>Nail</span><br> Treatments</h3>
							<div class="services_list">
			          			<ul>
				                   <li><a href="">Nail Cut & Filing + Nail Polish	30 min	₹ 161</a></li>
				                    <li><a href="">Manicure - Regular	30 min	₹ 483</a></li>
				                    <li><a href="">Absolute Moisturizing Gloves	30 min	₹ 604</a></li>
				                    <li><a href="">Pedicure - Regular	40 min	₹ 604</a></li>
				                    <li><a href="">Absolute Moisturizing Socks	30 min	₹ 725</a></li>
				                </ul>
			          		</div>
			  		   </div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/It helps keep your skin supple.jpg" alt="" />
					<h3><span>Facial</span><br>Treatment</h3>
							<div class="services_list">
								<ul>
				                   <li><a href="">Glistening Dew	45 min	₹ 909</a></li>
				                    <li><a href="">Eternal Hydro	45 min	₹ 909</a></li>
				                    <li><a href="">Pureza	45 min	₹ 909</a></li>
				                    <li><a href="">Enlighten	45 min	₹ 1449</a></li>
				                    <li><a href="">Oxygeneting	45 min	₹ 1576</a></li>
									 <li><a href="">All Bright	60 min	₹ 1817</a></li>
				                 <li><a href="">Facial	60 min	₹ 1000</a></li>
				                </ul>
							</div>
					</div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/44.jpg" alt=""   style=" height: 150px; width: 200px; "/>
					<h3><span>Hair</span><br>Treatments</h3>
							<div class="services_list">
			          			<ul>
			          				<li><a href="">Hair Cut 10 min ₹300</a></li>
				                    <li><a href="">Hair Smoothening 1 hr ₹5000</a></li>
				                   <li><a href="">Hair Curling 1 hr ₹4000</a></li>
				                    <li><a href="">Hair Designing 30 min ₹500</a></li>	
				                     <li><a href="">Hair Shambooing 30 min ₹500</a></li>	
									<li><a href="">Hair coloring	60 min	₹ 1020</a></li>
									<li><a href="">Hair straight	1hr	₹ 1500</a></li>									 
				                </ul>
			          		</div>
						</div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/body-spa.png" alt="" style=" height: 150px; width: 200px;"/>
					<h3><span>Body</span><br>Spa</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Foot Reflexology 30 min	₹ 776</a></li>
				                    <li><a href="">Back Massage	30 min	₹ 633</a></li>
				                    <li><a href="">Prenatel Massage	30 min	₹ 909</a></li>
				                    <li><a href="">Swedish Massage 60 min	₹ 1265		</a></li>
				                    <li><a href="">Champi Head Massage 30 min	₹ 633	</a></li>
										
	
	


				                </ul>
							</div>
					</div>
	            </div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/33.jpg" alt="" style=" height: 150px; width: 200px;" />
					<h3><span>Body</span><br>Treatments</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Includes Cleansing, Scrubbing, Mask and Serum	90 min	₹ 2898</a></li>
				                    <li><a href="">Waxing -Upper Lip	15 min	₹ 69</a></li>
				                    <li><a href="">Waxing - Full Body	100 min	₹ 1783</a></li>
				                    <li><a href="">Threading - Eyebrow	15 min	₹ 58	</a></li>
				                </ul>
							</div>
					</div>
	            </div>
				<div class="col_1_of_4 span_1_of_4">
				<img src="images/gorgeous-brides-kandivali-east-mumbai-0b089.jpg" alt="" style=" height: 150px; width: 200px;" />
					<h3><span>Bridal</span><br>Makeup</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Mehendi ₹500</a></li>
				                    <li><a href="">Nail Art ₹100</a></li>
				                    <li><a href="">Saree Draping ₹1000</a></li>
				                    <li><a href="">Make-up	₹4000</a></li>
				                    <li><a href="">Hair Styling ₹5000</a></li>
				                </ul>
							</div>
					</div>
					<div class="col_1_of_4 span_1_of_4">
				<img src="images/61.jpg" alt="" style=" height: 150px; width: 200px; "/>
					<h3><span>Eye</span><br>Makeup</h3>
					   <div class="services_list">
								<ul>
				                   <li><a href="">Eye Shadow ₹100</a></li>
				                    <li><a href="">Eye Liner ₹100</a></li>
				                    <li><a href="">Brow Liner ₹50</a></li>
				                    <li><a href="">Mascara	₹40</a></li>
				                    <li><a href="">Eye glass ₹500</a></li>
				                </ul>
							</div>
					</div>
	            </div>
				
	            <div class="section group example">
				<div class="col_1_of_2 span_1_of_2">
				   <h3>Highlights</h3>
				   <p><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua sed do eiusmod tempor.</span></p>
 				       <h4><span>2013</span>- sed do eiusmod tempor</h4>
 						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
 				    <h4><span>2010</span>- sed do eiusmod tempor</h4>
 						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
 				    <h4><span>2008</span>- sed do eiusmod tempor</h4>
 						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
 				       <h4><span>2005</span>- sed do eiusmod tempor</h4>
 						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
 				      <h4><span>2002</span>- sed do eiusmod tempor</h4>
 						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
 				</div>
				<div class="col_1_of_2 span_1_of_2">
				   <h3>Treatments</h3>
				   <div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/bridal-makeup.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>HAIR TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/eye-makeup.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>EYE MAKEUP</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/highlighting-hair.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>BRIDAL MAKEUP</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/pedicure.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>SKIN TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/spa.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>SPA TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
					<div class="hair_treatment">
						<div class="treatment_img">
							<img src="images/manicure.png" alt="">
						</div>
						<div class="treatment-desc">
							<p>NAIL TREATMENTS</p>
						</div>
						<div class="clear"></div>
					</div>
				</div>
		    </div>
     		 </div>
    		</div>
	    </div>
    </div>
 <div class="footer-strip"> </div>
 <div class="footer">
   	  <div class="wrap">
   	    <div class="footer_grides">
   	    	<div class="footer_grid1">
					<h3>Information</h3>
								<ul>
						            <li><a href="#">About Us</a></li>
						     		<li><a href="#">Privacy Policy</a></li>
						     		<li><a href="#">Newsletter</a></li>
						     		<li><a href="#">Site Map</a></li>						     		
						   	   </ul>	
						
					  	</div>
				<div class="footer_grid2">
					<h3>Get In Touch</h3>
							<div class="address">
							<ul>
						  	 <li>Reflection Salon & Spa,</li>
						  	  <li>New City,</li>
						  	   <li>USA.</li>
						  	 <li>www.reflection@gmail.com</li>
						  	 <li><span>Telephone :</span> +06821458963</li>
						  	 <li><span>Fax :</span> +01478523690</li>
						  </ul>
				   </div>				  
			     </div>
				<div class="footer_grid3">
					<h3>Our Company</h3>
						<div class="f_menu">
							   <ul>
						            <li><a href="#">About your Company</a></li>
						     		<li><a href="#">Terms &amp; conditions</a></li>
						     		<li><a href="#">News</a></li>
						     		<li><a href="#">Team of professionals</a></li>	
						     		<li><a href="#">Testimonials</a></li>					     		
						   	   </ul>
						</div>
				   </div>				
		  <div class="footer_grid4">
			<h3>Follow US</h3>
				<div class="img_list">
				    <ul>
					     <li><img src="images/28.png" alt=""><a href="#">Join Us on Facebook</a></li>
					     <li><img src="images/twitter.png" alt=""><a href="#">Follow Us on Twitter</a></li>
					     <li><img src="images/39.png" alt=""><a href="#">Share Us on Twitter</a></li>
				    </ul>
				</div>
		 </div>
	   <div class="clear"></div>
     </div>
    </div>
  </div>
<div class="copy_right">
				<p>Company Name © All rights Reseverd | Design by  <a href="http://w3layouts.com"> W3Layouts </a></p>
		 </div>
</body>
</html>

